document.addEventListener('DOMContentLoaded', async () => {
  const summarizeBtn = document.getElementById('summarizeBtn');
  const manualTranscribeBtn = document.getElementById('manualTranscribeBtn');
  const openOptions = document.getElementById('openOptions');
  const videoInfo = document.getElementById('videoInfo');
  const noVideo = document.getElementById('noVideo');
  const loading = document.getElementById('loading');
  const success = document.getElementById('success');
  const error = document.getElementById('error');
  const errorText = document.getElementById('errorText');
  const videoTitle = document.getElementById('videoTitle');
  const videoUrl = document.getElementById('videoUrl');
  const transcriptPreview = document.getElementById('transcriptPreview');
  const transcriptText = document.getElementById('transcriptText');

  // Check if configured
  const settings = await chrome.storage.sync.get(['anthropicKey']);
  if (!settings.anthropicKey) {
    showError('אנא הגדר את התוסף לפני השימוש. לחץ על ⚙️');
    document.getElementById('videoInfo').style.display = 'none';
    document.getElementById('summarizeBtn').style.display = 'none';
    document.getElementById('manualTranscribeBtn').style.display = 'none';
  }

  openOptions.addEventListener('click', (e) => {
    e.preventDefault();
    chrome.runtime.openOptionsPage();
  });

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  chrome.tabs.sendMessage(tab.id, { action: 'getVideoInfo' }, (response) => {
    if (!response || !response.videoUrl) {
      noVideo.style.display = 'block';
      return;
    }

    videoInfo.style.display = 'block';
    videoTitle.textContent = response.videoTitle || 'Unknown';
    videoUrl.textContent = response.videoUrl;
    videoUrl.href = response.videoUrl;

    if (response.transcript) {
      transcriptPreview.style.display = 'block';
      transcriptText.textContent = response.transcript.substring(0, 500) + (response.transcript.length > 500 ? '...' : '');
    }

    summarizeBtn.style.display = 'block';
    if (!response.transcript) {
      manualTranscribeBtn.style.display = 'block';
    }
  });

  summarizeBtn.addEventListener('click', async () => {
    showLoading();

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    chrome.tabs.sendMessage(tab.id, { action: 'getTranscript' }, async (response) => {
      if (!response || !response.transcript) {
        showError('לא הצלחתי לחלץ את התמליל');
        return;
      }

      const settings = await chrome.storage.sync.get([
        'anthropicKey',
        'emailjsPublicKey',
        'emailjsService',
        'emailjsTemplate',
        'toEmail',
        'language'
      ]);

      if (!settings.anthropicKey || !settings.toEmail) {
        showError('אנא הגדר את ההגדרות (אייפיאי מפתח ודוא"ל)');
        return;
      }

      try {
        chrome.runtime.sendMessage({
          action: 'summarizeAndSend',
          transcript: response.transcript,
          videoTitle: response.videoTitle,
          videoUrl: response.videoUrl,
          settings
        }, (response) => {
          if (response && response.success) {
            showSuccess();
          } else {
            showError(response?.error || 'שגיאה בלתי צפויה');
          }
        });
      } catch (err) {
        showError(err.message);
      }
    });
  });

  manualTranscribeBtn.addEventListener('click', async () => {
    showLoading();
    document.querySelector('p', loading).textContent = 'הפעל את הסרטון וחכה לתמליל...';

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    chrome.tabs.sendMessage(tab.id, { action: 'startSpeechRecognition' });
  });

  function showLoading() {
    noVideo.style.display = 'none';
    videoInfo.style.display = 'none';
    summarizeBtn.style.display = 'none';
    manualTranscribeBtn.style.display = 'none';
    success.style.display = 'none';
    error.style.display = 'none';
    loading.style.display = 'block';
  }

  function showSuccess() {
    loading.style.display = 'none';
    success.style.display = 'block';
    setTimeout(() => window.close(), 2000);
  }

  function showError(msg) {
    loading.style.display = 'none';
    errorText.textContent = msg;
    error.style.display = 'block';
  }
});
