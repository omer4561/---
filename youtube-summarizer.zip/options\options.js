document.addEventListener('DOMContentLoaded', async () => {
  const anthropicKey = document.getElementById('anthropicKey');
  const toEmail = document.getElementById('toEmail');
  const emailjsPublicKey = document.getElementById('emailjsPublicKey');
  const emailjsService = document.getElementById('emailjsService');
  const emailjsTemplate = document.getElementById('emailjsTemplate');
  const language = document.getElementById('language');
  const autoSend = document.getElementById('autoSend');
  const saveBtn = document.getElementById('saveBtn');
  const resetBtn = document.getElementById('resetBtn');
  const statusDiv = document.getElementById('status');

  // Load saved settings
  const settings = await chrome.storage.sync.get([
    'anthropicKey',
    'toEmail',
    'emailjsPublicKey',
    'emailjsService',
    'emailjsTemplate',
    'language',
    'autoSend'
  ]);

  anthropicKey.value = settings.anthropicKey || '';
  toEmail.value = settings.toEmail || '';
  emailjsPublicKey.value = settings.emailjsPublicKey || '';
  emailjsService.value = settings.emailjsService || '';
  emailjsTemplate.value = settings.emailjsTemplate || '';
  language.value = settings.language || 'עברית';
  autoSend.checked = settings.autoSend || false;

  // Save settings
  saveBtn.addEventListener('click', async () => {
    if (!anthropicKey.value || !toEmail.value) {
      showStatus('Please fill in all required fields (API key & email)', 'error');
      return;
    }

    await chrome.storage.sync.set({
      anthropicKey: anthropicKey.value,
      toEmail: toEmail.value,
      emailjsPublicKey: emailjsPublicKey.value,
      emailjsService: emailjsService.value,
      emailjsTemplate: emailjsTemplate.value,
      language: language.value,
      autoSend: autoSend.checked
    });

    showStatus('✅ הגדרות נשמרו בהצלחה!', 'success');
    setTimeout(() => statusDiv.style.display = 'none', 2000);
  });

  // Reset settings
  resetBtn.addEventListener('click', async () => {
    if (confirm('Are you sure? This will erase all settings.')) {
      await chrome.storage.sync.clear();
      anthropicKey.value = '';
      toEmail.value = '';
      emailjsPublicKey.value = '';
      emailjsService.value = '';
      emailjsTemplate.value = '';
      language.value = 'עברית';
      autoSend.checked = false;
      showStatus('⚠️ הגדרות נמחקו', 'error');
    }
  });

  function showStatus(message, type) {
    statusDiv.textContent = message;
    statusDiv.className = `status ${type}`;
    statusDiv.style.display = 'block';
  }
});
