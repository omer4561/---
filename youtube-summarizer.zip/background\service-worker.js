// Open onboarding on first install
chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === 'install') {
    const settings = await chrome.storage.sync.get(['anthropicKey']);
    if (!settings.anthropicKey) {
      chrome.tabs.create({ url: 'chrome-extension://' + chrome.runtime.id + '/onboarding/onboarding.html' });
    }
  }
});

// Listen for messages from popup/content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'summarizeAndSend') {
    handleSummarizeAndSend(request, sendResponse);
    return true; // Keep channel open for async response
  }
});

async function handleSummarizeAndSend(request, sendResponse) {
  try {
    const { transcript, videoTitle, videoUrl, settings } = request;

    if (!settings.anthropicKey) {
      sendResponse({ success: false, error: 'Missing Claude API key' });
      return;
    }

    if (!transcript) {
      sendResponse({ success: false, error: 'No transcript available' });
      return;
    }

    // Call Claude API for summary and translation
    const summary = await summarizeWithClaude(
      transcript,
      settings.anthropicKey,
      settings.language
    );

    if (!summary) {
      sendResponse({ success: false, error: 'Failed to generate summary' });
      return;
    }

    // Send email via EmailJS
    const emailSent = await sendEmailViaEmailJS(
      summary,
      videoTitle,
      videoUrl,
      settings
    );

    if (!emailSent) {
      sendResponse({ success: false, error: 'Failed to send email' });
      return;
    }

    sendResponse({ success: true });
  } catch (error) {
    console.error('[Extension] Error in summarizeAndSend:', error);
    sendResponse({ success: false, error: error.message });
  }
}

async function summarizeWithClaude(transcript, apiKey, language) {
  try {
    // Validate inputs
    if (!apiKey || !apiKey.startsWith('sk-ant-')) {
      throw new Error('Invalid API key format');
    }
    if (!transcript || transcript.length === 0) {
      throw new Error('Empty transcript');
    }
    if (transcript.length > 100000) {
      transcript = transcript.substring(0, 100000);
    }

    // Sanitize language input
    const validLanguages = ['English', 'Hebrew', 'עברית', 'Spanish', 'French', 'German', 'Arabic', 'Chinese'];
    const sanitizedLanguage = validLanguages.includes(language) ? language : 'English';

    const prompt = `Summarize the following video transcript in ${sanitizedLanguage}.

Provide:
1) A 3-sentence summary
2) 5 key points as bullet points

Keep it concise and informative.

Transcript:
${transcript}`;

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
        'content-type': 'application/json'
      },
      body: JSON.stringify({
        model: 'claude-haiku-4-5-20251001',
        max_tokens: 1024,
        messages: [{
          role: 'user',
          content: prompt
        }]
      })
    });

    if (!response.ok) {
      const error = await response.json();
      console.error('[Extension] Claude API error:', error);
      throw new Error(`API error: ${response.status}`);
    }

    const data = await response.json();
    if (!data.content || !data.content[0] || !data.content[0].text) {
      throw new Error('Invalid API response');
    }
    return data.content[0].text;
  } catch (error) {
    console.error('[Extension] Error calling Claude API:', error);
    return null;
  }
}

async function sendEmailViaEmailJS(summary, videoTitle, videoUrl, settings) {
  try {
    // Validate EmailJS settings
    if (!settings.emailjsPublicKey || !settings.emailjsService || !settings.emailjsTemplate) {
      throw new Error('Missing EmailJS configuration');
    }

    if (!settings.toEmail) {
      throw new Error('Missing recipient email');
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(settings.toEmail)) {
      throw new Error('Invalid email address format');
    }

    // Validate and sanitize inputs
    if (!summary || typeof summary !== 'string') {
      throw new Error('Invalid summary');
    }

    const videoTitleClean = String(videoTitle || 'Video').substring(0, 200);
    const videoUrlClean = String(videoUrl || 'Unknown').substring(0, 500);

    // Validate URL format
    try {
      new URL(videoUrlClean);
    } catch {
      throw new Error('Invalid video URL');
    }

    // Prepare email payload
    const templateParams = {
      to_email: settings.toEmail,
      video_title: videoTitleClean,
      video_url: videoUrlClean,
      summary: summary,
      language: settings.language || 'English'
    };

    // Send via EmailJS with timeout
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10000); // 10 second timeout

    const response = await fetch('https://api.emailjs.com/api/v1.0/email/send', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Request-ID': crypto.randomUUID ? crypto.randomUUID() : 'request-' + Date.now()
      },
      body: JSON.stringify({
        service_id: settings.emailjsService,
        template_id: settings.emailjsTemplate,
        user_id: settings.emailjsPublicKey,
        template_params: templateParams
      }),
      signal: controller.signal
    });

    clearTimeout(timeout);

    if (!response.ok) {
      const error = await response.json();
      console.error('[Extension] EmailJS error:', error);
      throw new Error(`Email service error: ${response.status}`);
    }

    console.log('[Extension] Email sent successfully');
    return true;
  } catch (error) {
    console.error('[Extension] Error sending email:', error);
    return false;
  }
}

console.log('[Extension] Service Worker loaded');
