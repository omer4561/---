// Onboarding setup wizard
const steps = [
  { id: 'step1', name: 'Claude API', status: 'step1Status' },
  { id: 'step2', name: 'EmailJS', status: 'step2Status' },
  { id: 'step3', name: 'Email', status: 'step3Status' },
  { id: 'step4', name: 'Language', status: 'step4Status' }
];

let currentStep = 0;
let completedSteps = {
  claude: false,
  emailjs: false,
  email: false,
  language: false
};

// Load saved settings
document.addEventListener('DOMContentLoaded', async () => {
  const settings = await chrome.storage.sync.get([
    'anthropicKey',
    'emailjsPublicKey',
    'emailjsService',
    'emailjsTemplate',
    'toEmail',
    'language'
  ]);

  if (settings.anthropicKey) {
    completedSteps.claude = true;
    updateStepStatus(0);
  }

  if (settings.emailjsPublicKey && settings.emailjsService && settings.emailjsTemplate) {
    completedSteps.emailjs = true;
    updateStepStatus(1);
  }

  if (settings.toEmail) {
    completedSteps.email = true;
    document.getElementById('email').value = settings.toEmail;
    updateStepStatus(2);
  }

  if (settings.language) {
    completedSteps.language = true;
    document.getElementById('language').value = settings.language;
    updateStepStatus(3);
  }

  updateProgress();
  checkCompletion();
});

function toggleStep(stepNum) {
  const inputs = document.querySelectorAll(`#step${stepNum} .input-group[style*="display: none"]`);
  inputs.forEach(input => {
    input.style.display = input.style.display === 'none' ? 'block' : 'none';
  });
}

function updateStepStatus(stepIndex) {
  const step = steps[stepIndex];
  const statusEl = document.getElementById(step.status);

  if (completedSteps[Object.keys(completedSteps)[stepIndex]]) {
    statusEl.textContent = '✓ בוצע';
    document.getElementById(step.id).classList.add('completed');
    document.getElementById(step.id).classList.remove('active');
  }
}

function updateProgress() {
  const completed = Object.values(completedSteps).filter(v => v).length;
  const progress = (completed / 4) * 100;
  document.getElementById('progressFill').style.width = progress + '%';
}

function checkCompletion() {
  const allComplete = Object.values(completedSteps).every(v => v);
  if (allComplete) {
    document.querySelector('.steps').style.display = 'none';
    document.getElementById('completionMessage').classList.add('show');
  }
}

// Claude API
function openClaude() {
  window.open('https://console.anthropic.com/keys', '_blank');
  toggleStep(1);
  document.getElementById('claudeInput').style.display = 'block';
}

async function saveClaudeKey() {
  const key = document.getElementById('claudeKey').value.trim();
  if (!key) {
    alert('אנא הדבק את ה-API Key');
    return;
  }

  await chrome.storage.sync.set({ anthropicKey: key });
  completedSteps.claude = true;
  updateStepStatus(0);
  updateProgress();

  document.getElementById('step1').classList.add('completed');
  document.getElementById('claudeInput').style.display = 'none';

  if (currentStep === 0) currentStep++;

  checkCompletion();
}

// EmailJS
function openEmailJS() {
  window.open('https://www.emailjs.com/', '_blank');
  toggleStep(2);
  document.getElementById('emailjsInput').style.display = 'block';
}

async function saveEmailJSKeys() {
  const publicKey = document.getElementById('emailjsPublicKey').value.trim();
  const service = document.getElementById('emailjsService').value.trim();
  const template = document.getElementById('emailjsTemplate').value.trim();

  if (!publicKey || !service || !template) {
    alert('אנא מלא את כל השדות');
    return;
  }

  await chrome.storage.sync.set({
    emailjsPublicKey: publicKey,
    emailjsService: service,
    emailjsTemplate: template
  });

  completedSteps.emailjs = true;
  updateStepStatus(1);
  updateProgress();

  document.getElementById('step2').classList.add('completed');
  document.getElementById('emailjsInput').style.display = 'none';

  checkCompletion();
}

// Email
async function saveEmail() {
  const email = document.getElementById('email').value.trim();
  if (!email || !email.includes('@')) {
    alert('אנא הזן דוא"ל תקין');
    return;
  }

  await chrome.storage.sync.set({ toEmail: email });
  completedSteps.email = true;
  updateStepStatus(2);
  updateProgress();

  document.getElementById('step3').classList.add('completed');

  checkCompletion();
}

// Language
async function saveLanguage() {
  const language = document.getElementById('language').value;
  await chrome.storage.sync.set({ language });
  completedSteps.language = true;
  updateStepStatus(3);
  updateProgress();

  document.getElementById('step4').classList.add('completed');

  checkCompletion();
}

// Close onboarding
function closeOnboarding() {
  window.close();
}
