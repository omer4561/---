let recognition = null;
let isRecording = false;
let transcript = '';

// Initialize Speech Recognition
function initSpeechRecognition() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) return null;

  recognition = new SpeechRecognition();
  recognition.continuous = true;
  recognition.interimResults = false;
  recognition.lang = 'en-US';

  recognition.onstart = () => {
    isRecording = true;
    transcript = '';
    console.log('[Extension] Speech recognition started');
  };

  recognition.onresult = (event) => {
    for (let i = event.resultIndex; i < event.results.length; i++) {
      if (event.results[i].isFinal) {
        transcript += event.results[i][0].transcript + ' ';
      }
    }
  };

  recognition.onerror = (event) => {
    console.error('[Extension] Speech recognition error:', event.error);
  };

  recognition.onend = () => {
    isRecording = false;
    console.log('[Extension] Speech recognition ended');
  };

  return recognition;
}

// Get video information (title, URL, etc.)
async function getVideoInfo() {
  const url = window.location.href;
  let videoTitle = document.title || 'Unknown';

  // Try to get more specific title from common platforms
  if (url.includes('youtube.com') || url.includes('youtu.be')) {
    const titleEl = document.querySelector('h1 yt-formatted-string');
    if (titleEl) videoTitle = titleEl.textContent;
  } else if (url.includes('udemy.com')) {
    const titleEl = document.querySelector('[data-test="course-title"]') || document.querySelector('h1');
    if (titleEl) videoTitle = titleEl.textContent;
  } else if (url.includes('coursera.org')) {
    const titleEl = document.querySelector('h1');
    if (titleEl) videoTitle = titleEl.textContent;
  } else if (url.includes('vimeo.com')) {
    const titleEl = document.querySelector('[itemprop="name"]') || document.title;
    if (titleEl) videoTitle = typeof titleEl === 'string' ? titleEl : titleEl.textContent;
  }

  return {
    videoUrl: url,
    videoTitle: videoTitle.trim()
  };
}

// Extract YouTube transcript
async function getYouTubeTranscript() {
  try {
    // Look for ytInitialPlayerResponse in page
    const scripts = Array.from(document.querySelectorAll('script:not([src])'));
    let playerResponse = null;

    for (const script of scripts) {
      if (script.textContent.includes('ytInitialPlayerResponse') && script.textContent.length < 1000000) {
        try {
          const match = script.textContent.match(/var ytInitialPlayerResponse = ({.+?});(?:\n|$)/);
          if (match && match[1].length < 500000) {
            playerResponse = JSON.parse(match[1]);
            break;
          }
        } catch {
          continue;
        }
      }
    }

    if (!playerResponse) return null;

    // Navigate to caption tracks safely
    const captions = playerResponse?.captions?.playerCaptionsTracklistRenderer?.captionTracks;
    if (!Array.isArray(captions) || captions.length === 0) return null;

    // Get first caption track (usually English)
    const captionTrack = captions[0];
    if (!captionTrack?.baseUrl || typeof captionTrack.baseUrl !== 'string') return null;

    // Validate URL
    try {
      new URL(captionTrack.baseUrl);
    } catch {
      return null;
    }

    // Fetch caption XML with timeout
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000);

    const response = await fetch(captionTrack.baseUrl, { signal: controller.signal });
    clearTimeout(timeout);

    if (!response.ok) return null;

    const xml = await response.text();
    if (xml.length > 500000) return null;

    // Parse XML to plain text
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(xml, 'text/xml');

    if (xmlDoc.getElementsByTagName('parsererror').length > 0) {
      return null;
    }

    const textElements = xmlDoc.querySelectorAll('text');
    const transcriptText = Array.from(textElements)
      .map(el => el.textContent)
      .filter(text => text && text.trim())
      .join(' ')
      .trim();

    return transcriptText.length > 0 ? transcriptText : null;
  } catch (error) {
    console.error('[Extension] Error fetching YouTube transcript:', error);
    return null;
  }
}

// Extract transcript from HTML5 <track> element (VTT files)
async function getHTMLTrackTranscript() {
  try {
    const video = document.querySelector('video');
    if (!video) return null;

    const track = video.querySelector('track[kind="subtitles"], track[kind="captions"]');
    if (!track || !track.src) return null;

    // Validate and construct URL safely
    let trackUrl;
    try {
      trackUrl = new URL(track.src, window.location.href).href;
      // Only allow https for security
      if (!trackUrl.startsWith('https://') && !trackUrl.startsWith('http://')) {
        return null;
      }
    } catch {
      return null;
    }

    // Fetch with timeout
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000);

    const response = await fetch(trackUrl, { signal: controller.signal });
    clearTimeout(timeout);

    if (!response.ok || response.status !== 200) return null;

    const vttText = await response.text();
    if (vttText.length > 500000 || !vttText) return null;

    // Parse VTT to plain text
    const lines = vttText.split('\n');
    const transcript = lines
      .filter(line => {
        const trimmed = line.trim();
        return trimmed &&
               !trimmed.includes('-->') &&
               !trimmed.startsWith('WEBVTT') &&
               !trimmed.match(/^\d{2}:/) &&
               trimmed.length < 500;
      })
      .map(line => line.trim())
      .filter(line => line)
      .join(' ')
      .trim();

    return transcript.length > 0 ? transcript : null;
  } catch (error) {
    console.error('[Extension] Error fetching track transcript:', error);
    return null;
  }
}

// Detect if there's a video on the page
function hasVideo() {
  return !!document.querySelector('video') ||
         window.location.href.includes('youtube.com') ||
         window.location.href.includes('youtu.be') ||
         window.location.href.includes('udemy.com') ||
         window.location.href.includes('coursera.org') ||
         window.location.href.includes('vimeo.com') ||
         window.location.href.includes('teachable') ||
         window.location.href.includes('thinkific');
}

// Get transcript from available sources
async function getTranscript() {
  let transcriptText = null;

  // Try YouTube first
  if (window.location.href.includes('youtube.com') || window.location.href.includes('youtu.be')) {
    transcriptText = await getYouTubeTranscript();
  }

  // Try HTML5 track element (works for Udemy, Coursera, Vimeo, etc.)
  if (!transcriptText) {
    transcriptText = await getHTMLTrackTranscript();
  }

  return transcriptText;
}

// Start manual speech recognition
function startSpeechRecognition() {
  if (!recognition) {
    recognition = initSpeechRecognition();
  }

  if (!recognition) {
    console.error('[Extension] Speech Recognition API not available');
    return;
  }

  if (isRecording) {
    recognition.stop();
  } else {
    transcript = '';
    recognition.start();
  }
}

// Listen for messages from popup or background
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getVideoInfo') {
    getVideoInfo().then(info => {
      sendResponse({
        ...info,
        hasVideo: hasVideo()
      });
    });
    return true;
  }

  if (request.action === 'getTranscript') {
    getTranscript().then(transcriptText => {
      sendResponse({
        transcript: transcriptText,
        ...getVideoInfoSync()
      });
    });
    return true;
  }

  if (request.action === 'startSpeechRecognition') {
    startSpeechRecognition();
    // Send transcript back periodically
    const interval = setInterval(() => {
      if (!isRecording) {
        clearInterval(interval);
        chrome.runtime.sendMessage({
          action: 'transcriptReady',
          transcript: transcript,
          ...getVideoInfoSync()
        });
      }
    }, 1000);
    sendResponse({ success: true });
    return true;
  }
});

// Helper function to get video info synchronously
function getVideoInfoSync() {
  const url = window.location.href;
  let videoTitle = document.title || 'Unknown';

  if (url.includes('youtube.com') || url.includes('youtu.be')) {
    const titleEl = document.querySelector('h1 yt-formatted-string');
    if (titleEl) videoTitle = titleEl.textContent;
  } else if (url.includes('udemy.com')) {
    const titleEl = document.querySelector('[data-test="course-title"]') || document.querySelector('h1');
    if (titleEl) videoTitle = titleEl.textContent;
  }

  return {
    videoUrl: url,
    videoTitle: videoTitle.trim()
  };
}

console.log('[Extension] Content script loaded');
